const { DynamoDBClient } = require("@aws-sdk/client-dynamodb");
const { DynamoDBDocumentClient, PutCommand } = require("@aws-sdk/lib-dynamodb");
const crypto = require("crypto");

const client = new DynamoDBClient({});
const docClient = DynamoDBDocumentClient.from(client);
const TABLE = process.env.DYNAMODB_TABLE_AUDIT_LOGS;

exports.handler = async (event) => {
  console.log("Received EventBridge event:", JSON.stringify(event, null, 2));

  const detail = event.detail || {};
  const action = event["detail-type"] || "UNKNOWN_ACTION";
  const now = new Date();
  const ttlExpiry = Math.floor(now.getTime() / 1000) + 86400; // 1-day TTL

  let entityType = "other";
  let entityId = "unknown";
  
  if (action === "ProductCreated" || action === "ProductUpdated") {
    entityType = "product";
    entityId = detail.productId || "unknown";
  } else if (action === "OrderPlaced") {
    entityType = "order";
    entityId = detail.orderId || "unknown";
  } else if (action === "InventoryLow") {
    entityType = "inventory";
    entityId = detail.productId || "unknown";
  }

  const item = {
    logId: crypto.randomUUID(),
    adminId: detail.adminId || detail.userId || "unknown",
    adminEmail: detail.adminEmail || detail.userEmail || "system",
    action: action.toUpperCase(),
    entityType,
    entityId,
    changes: detail.changes ? JSON.stringify(detail.changes) : JSON.stringify(detail),
    timestamp: detail.timestamp || now.toISOString(),
    ttlExpiry,
  };

  try {
    await docClient.send(
      new PutCommand({
        TableName: TABLE,
        Item: item,
      })
    );
    console.log(`[Lambda Audit] Successfully logged action ${action} to DynamoDB`);
    return { status: "success" };
  } catch (err) {
    console.error("[Lambda Audit] Error writing to DynamoDB:", err.message);
    throw err;
  }
};
